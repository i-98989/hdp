var BUNDY = {
    $objects : {},
    functions : {
        windowLoad: [],
        windowResize: [],
        preloadComplete: []
    },
    instances : {},
    vars: {},
    async : {},
    images : []
};